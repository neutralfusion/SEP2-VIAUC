package model;

import com.google.gson.Gson;
import mediator.RemoteModel;
import mediator.RemoteModelManager;
import persistence.*;
import persistence.Order;
import persistence.User;
import utility.observer.listener.GeneralListener;
import utility.observer.subject.PropertyChangeHandler;

import java.util.ArrayList;

public class ModelManager implements Model {
    private final Gson gson;
    private final ArrayList<Type> carTypes;
    private final ArrayList<Place> places;
    private final User userPersistence;
    private final persistence.Car carPersistence;
    private final Order orderPersistence;
    private final PropertyChangeHandler<String, String> property;

    public ModelManager() {
        gson = new Gson();
        property = new PropertyChangeHandler<>(this, true);
        carPersistence = new CarPersistence();
        orderPersistence = new OrderPersistence();
        persistence.Place placePersistence = new PlacePersistence();
        persistence.Type typePersistence = new TypePersistence();
        carTypes = typePersistence.getCarTypes();
        places = placePersistence.getAllPlaces();
        userPersistence = new UserPersistence();
    }

    @Override
    public void registerUser(String name, String surname, String phoneNo, String username, String password) {
        userPersistence.register(name, surname, phoneNo, username, password);
    }

    @Override
    public boolean login(String username, String password, String userType) {
        return userPersistence.login(username, password, userType);
    }

    @Override
    public void updateDetails(String fname, String lname, String phoneNo, String username, String password) {
        userPersistence.updateDetails(fname, lname, phoneNo, username, password);
    }

    @Override
    public model.User getUserDetails(String username) {
        return userPersistence.getUserDetails(username);
    }

    @Override
    public ArrayList<model.User> getAllClients() {
        return userPersistence.getAllClients();
    }

    @Override
    public ArrayList<Car> getAllCars() {
        return carPersistence.getAllCars();
    }

    @Override
    public ArrayList<Type> getCarTypes() {
        return carTypes;
    }

    @Override
    public void addCar(Car car) {
        carPersistence.addCar(car);
    }

    @Override
    public void removeCar(String licensePlate) {
        carPersistence.removeCar(licensePlate);
    }

    @Override
    public ArrayList<Place> getAllPlaces() {
        return places;
    }

    @Override
    public Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) {
        Car car = orderPersistence.rentCar(username, licensePlate, pickingPlace, returningPlace);
        if (car != null) {
            property.firePropertyChange("rented_car", username, gson.toJson(car));
            System.out.println("Sent event to client");
            return car;
        }

        return null;
    }

    @Override
    public void returnCar(String username, String licensePlate) {
        property.firePropertyChange("return_car", username, licensePlate);
        orderPersistence.returnCar(username, licensePlate);
    }

    @Override
    public ArrayList<Car> getRentedCars(String username) {
        return orderPersistence.getRentedCars(username);
    }

    @Override
    public boolean addListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.addListener(listener, propertyNames);
    }

    @Override
    public boolean removeListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.removeListener(listener, propertyNames);
    }
}
