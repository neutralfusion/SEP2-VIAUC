package model;

import utility.observer.subject.LocalSubject;

import java.util.ArrayList;

public interface Model extends LocalSubject<String, String> {
    void registerUser(String name, String surname, String phoneNo, String username, String password);
    boolean login(String username, String password, String userType);
    void updateDetails(String fname, String lname, String phoneNo, String username, String password);
    User getUserDetails(String username);
    ArrayList<User> getAllClients();
    ArrayList<Type> getCarTypes();
    ArrayList<Car> getAllCars();
    void addCar(Car car);
    void removeCar(String licensePlate);
    ArrayList<Place> getAllPlaces();
    Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace);
    void returnCar(String username, String licensePlate);
    ArrayList<Car> getRentedCars(String username);
}
