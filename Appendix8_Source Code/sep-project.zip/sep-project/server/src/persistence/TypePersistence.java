package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TypePersistence implements Type {

    @Override
    public ArrayList<model.Type> getCarTypes() {
        ArrayList<model.Type> types = new ArrayList<>();
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("select * from CarType");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                types.add(new model.Type(resultSet.getString("type")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return types;
    }
}
