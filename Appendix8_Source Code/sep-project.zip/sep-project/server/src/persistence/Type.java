package persistence;

import java.util.ArrayList;

public interface Type {
    ArrayList<model.Type> getCarTypes();
}
