package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlacePersistence implements Place {

    @Override
    public ArrayList<model.Place> getAllPlaces() {
        ArrayList<model.Place> places = new ArrayList<>();
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("select * from Place");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                places.add(new model.Place(resultSet.getString("city"), resultSet.getString("address"), resultSet.getInt("zipCode")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return places;
    }
}
