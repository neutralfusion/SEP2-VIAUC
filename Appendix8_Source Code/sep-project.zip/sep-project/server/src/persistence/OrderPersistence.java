package persistence;

import model.Car;
import model.Type;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderPersistence implements Order {

    @Override
    public Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("insert into Rent values (default, ?, ?, ?, ?)");
            statement.setString(1, username);
            statement.setString(2, licensePlate);
            statement.setString(3, pickingPlace);
            statement.setString(4, returningPlace);
            statement.executeUpdate();

            statement = connection.prepareStatement("update Car set isRented = true where licenceplate = ? returning *");
            statement.setString(1, licensePlate);
            ResultSet resultSet =  statement.executeQuery();
            if (resultSet.next()) {
                return new Car(resultSet.getString("brand"), resultSet.getString("model"), resultSet.getString("licenceplate"), new Type(resultSet.getString("type")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public void returnCar(String username, String licensePlate) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("delete from Rent where username = ? and licenceplate = ?");
            statement.setString(1, username);
            statement.setString(2, licensePlate);
            statement.executeUpdate();

            statement = connection.prepareStatement("update Car set isRented = false where licenceplate = ?");
            statement.setString(1, licensePlate);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public ArrayList<Car> getRentedCars(String username) {
        try (Connection connection = MyConnection.getInstance().get()) {
            ArrayList<Car> rentedCars = new ArrayList<>();
            PreparedStatement statement = connection.prepareStatement("select * from Rent join Car using (licencePlate) where username = ?");
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println(resultSet.getString("licenceplate"));
                rentedCars.add(new Car(resultSet.getString("brand"), resultSet.getString("model"), resultSet.getString("licenceplate"), new Type(resultSet.getString("type"))));
            }
            return rentedCars;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return null;
    }
}
