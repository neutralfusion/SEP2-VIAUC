package persistence;

import java.util.ArrayList;

public interface Place {
    ArrayList<model.Place> getAllPlaces();
}
