package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserPersistence implements User {

    public static final String NAME = "fname", SURNAME = "lname", PHONE_NO = "phoneNumber", PASSWORD = "password";

    @Override
    public void register(String fname, String lname, String phoneNo, String username, String password) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("insert into Client (fname, lname, phonenumber, username, password, clientid) values (?, ?, ?, ?, ?, default)");
            statement.setString(1, fname);
            statement.setString(2, lname);
            statement.setString(3, phoneNo);
            statement.setString(4, username);
            statement.setString(5, password);
            statement.executeUpdate();
        } catch (SQLException e) {
            if (e.getMessage().contains("Username already exists")) {
                throw new IllegalArgumentException("Username is taken");
            }
            System.out.println(e.getMessage());
        }
    }

    @Override
    public boolean login(String username, String password, String userType) {
        try (Connection connection = MyConnection.getInstance().get()) {
            String table = "";
            if (userType.equals("client")) {
                table = "Client";
            } else if (userType.equals("employee")) {
                table = "Employee";
            }
            PreparedStatement statement = connection.prepareStatement("select * from " + table + " where username = ? and password = ?");
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    @Override
    public void updateDetails(String fname, String lname, String phoneNo, String username, String password) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("update Client set (fname, lname, phoneNumber, password) = (?, ?, ?, ?) where username = ?");
            statement.setString(1, fname);
            statement.setString(2, lname);
            statement.setString(3, phoneNo);
            statement.setString(4, password);
            statement.setString(5, username);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void edit(String field, String value, String username) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("update Client set " + field + " = ? where username = ?");
            statement.setString(1, value);
            statement.setString(2, username);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public model.User getUserDetails(String username) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("select * from Client where username = ?");
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new model.User(resultSet.getString("fname"), resultSet.getString("lname"), resultSet.getString("phoneNumber"), resultSet.getString("username"), resultSet.getString("password"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public ArrayList<model.User> getAllClients() {
        ArrayList<model.User> clients = new ArrayList<>();
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("select * from Client");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                clients.add(new model.User(resultSet.getString("fname"), resultSet.getString("lname"), resultSet.getString("phoneNumber"), resultSet.getString("username"), resultSet.getString("password")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return clients;
    }
}
