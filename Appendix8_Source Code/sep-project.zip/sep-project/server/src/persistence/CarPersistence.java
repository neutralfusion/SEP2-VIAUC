package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CarPersistence implements Car {

    @Override
    public void addCar(model.Car car) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("insert into Car (brand, model, type, licenceplate) values (?, ?, ?, ?)");
            statement.setString(1, car.getBrand());
            statement.setString(2, car.getModel());
            statement.setString(3, car.getType().getCarType());
            statement.setString(4, car.getLicensePlate());
            statement.executeUpdate();
        } catch (SQLException e) {
            if (e.getMessage().contains("already exists")) {
                throw new IllegalArgumentException("Car is already in the system");
            }
            System.out.println(e.getMessage());
        }
    }

    @Override
    public ArrayList<model.Car> getAllCars() {
        ArrayList<model.Car> cars = new ArrayList<>();
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("select * from Car");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                model.Car car = new model.Car(resultSet.getString("brand"), resultSet.getString("model"), resultSet.getString("licencePlate"), new model.Type(resultSet.getString("type")));
                car.setRented(resultSet.getBoolean("isRented"));
                cars.add(car);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return cars;
    }

    @Override
    public void removeCar(String licensePlate) {
        try (Connection connection = MyConnection.getInstance().get()) {
            PreparedStatement statement = connection.prepareStatement("delete from Car where licenceplate = ?");
            statement.setString(1, licensePlate);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
