package persistence;

import model.Car;

import java.util.ArrayList;

public interface Order {
    Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace);
    void returnCar(String username, String licensePlate);
    ArrayList<Car> getRentedCars(String username);
}
