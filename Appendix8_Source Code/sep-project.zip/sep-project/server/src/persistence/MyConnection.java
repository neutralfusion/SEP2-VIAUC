package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
    private static final String URL = "INSERT_URL_HERE";
    private static final String USER = "INSERT_USER_HERE";
    private static final String PASSWORD = "INSERT_PASSWORD_HERE";
    private static MyConnection instance;

    private MyConnection() throws SQLException {
        DriverManager.registerDriver(new org.postgresql.Driver());
    }

    public static synchronized MyConnection getInstance() throws SQLException {
        if (instance == null) instance = new MyConnection();
        return instance;
    }

    public Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
