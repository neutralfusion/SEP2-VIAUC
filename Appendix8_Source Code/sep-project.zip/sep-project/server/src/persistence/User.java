package persistence;

import java.util.ArrayList;

public interface User {
    void register(String name, String surname, String phoneNo, String username, String password);
    boolean login(String username, String password, String userType);
    void updateDetails(String fname, String lname, String phoneNo, String username, String password);
    void edit(String field, String value, String username);
    model.User getUserDetails(String username);
    ArrayList<model.User> getAllClients();
}
