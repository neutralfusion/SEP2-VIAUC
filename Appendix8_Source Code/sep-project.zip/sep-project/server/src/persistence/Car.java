package persistence;

import java.util.ArrayList;

public interface Car {
    void addCar(model.Car car);
    ArrayList<model.Car> getAllCars();
    void removeCar(String licensePlate);
}
