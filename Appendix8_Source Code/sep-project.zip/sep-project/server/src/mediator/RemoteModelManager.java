package mediator;

import model.*;
import utility.observer.event.ObserverEvent;
import utility.observer.listener.GeneralListener;
import utility.observer.listener.LocalListener;
import utility.observer.subject.PropertyChangeHandler;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class RemoteModelManager implements RemoteModel, LocalListener<String, String> {

    private Model model;
    private PropertyChangeHandler<String, String> property;

    public RemoteModelManager(Model model) {
        try {
            property = new PropertyChangeHandler<>(this, true);
            this.model = model;
            model.addListener(this);
            LocateRegistry.createRegistry(1099);
            UnicastRemoteObject.exportObject(this, 0);
            Naming.rebind("wheelsquick", this);
            System.out.println("Server started");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void register(String fname, String lname, String phoneNo, String username, String password) {
        model.registerUser(fname, lname, phoneNo, username, password);
    }

    @Override
    public boolean login(String username, String password, String userType) {
        return model.login(username, password, userType);
    }

    @Override
    public void updateDetails(String fname, String lname, String phoneNo, String username, String password) throws RemoteException {
        model.updateDetails(fname, lname, phoneNo, username, password);
    }

    @Override
    public User getUserDetails(String username) throws RemoteException {
        return model.getUserDetails(username);
    }

    @Override
    public ArrayList<User> getAllClients() throws RemoteException {
        return model.getAllClients();
    }

    @Override
    public ArrayList<Type> getCarTypes() throws RemoteException {
        return model.getCarTypes();
    }

    @Override
    public ArrayList<Car> getAllCars() throws RemoteException {
        return model.getAllCars();
    }

    @Override
    public void addCar(Car car) throws RemoteException {
        model.addCar(car);
    }

    @Override
    public void removeCar(String licensePlate) throws RemoteException {
        model.removeCar(licensePlate);
    }

    @Override
    public ArrayList<Place> getAllPlaces() throws RemoteException {
        return model.getAllPlaces();
    }

    @Override
    public Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) throws RemoteException {
        return model.rentCar(username, licensePlate, pickingPlace, returningPlace);
    }

    @Override
    public void returnCar(String username, String licensePlate) throws RemoteException {
        model.returnCar(username, licensePlate);
    }

    @Override
    public ArrayList<Car> getRentedCars(String username) throws RemoteException {
        return model.getRentedCars(username);
    }

    @Override
    public void propertyChange(ObserverEvent<String, String> event) {
        property.firePropertyChange(event.getPropertyName(), event.getValue1(), event.getValue2());
        System.out.println(event.getPropertyName() + " " + event.getValue1() + " " + event.getValue2() + " in RemoteModelManager");
    }

    @Override
    public boolean addListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.addListener(listener, propertyNames);
    }

    @Override
    public boolean removeListener(GeneralListener<String, String> listener, String... propertyNames){
        return property.removeListener(listener, propertyNames);
    }
}
