import javafx.application.Application;
import javafx.stage.Stage;
import mediator.RemoteModel;
import mediator.RemoteModelManager;
import model.Model;
import model.ModelManager;

public class MyApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Model model = new ModelManager();
        RemoteModel remoteModel = new RemoteModelManager(model);
    }
}
