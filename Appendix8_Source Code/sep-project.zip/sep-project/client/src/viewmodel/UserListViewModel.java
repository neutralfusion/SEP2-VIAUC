package viewmodel;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Model;
import model.User;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class UserListViewModel {
    private final Model model;
    private final ViewState state;
    private final ObservableList<UserViewModel> userList;

    public UserListViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        this.userList = FXCollections.observableArrayList();
        reset();
    }

    public void reset() {
        loadClientList();
    }

    private void loadClientList() {
        userList.clear();
        try {
            ArrayList<User> clients = model.getAllClients();
            for (User c : clients) {
                userList.add(new UserViewModel(c));
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<UserViewModel> getUserList() {
        return userList;
    }
}
