package viewmodel;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Car;
import model.Model;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class CarListViewModel {
    private final Model model;
    private final ViewState state;
    private final ObservableList<CarViewModel> carList;

    public CarListViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        carList = FXCollections.observableArrayList();
        reset();
    }

    public void reset() {
        loadCarList();
    }

    private void loadCarList() {
        carList.clear();
        try {
            ArrayList<Car> cars = model.getAllCars();
            for (Car c : cars) {
                carList.add(new CarViewModel(c));
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void removeCar(CarViewModel car) {
        try {
            carList.remove(car);
            model.removeCar(car.getLicensePlateProperty());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<CarViewModel> getCarList() {
        return carList;
    }
}
