package viewmodel;

import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Car;
import model.Model;
import utility.observer.event.ObserverEvent;
import utility.observer.listener.LocalListener;

public class EmployeeDashboardViewModel implements LocalListener<String, String> {
    private final Model model;
    private final ViewState state;
    private StringProperty errorLabel;

    public EmployeeDashboardViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        this.errorLabel = new SimpleStringProperty();
        model.addListener(this);
    }

    public void reset() {
        errorLabel.setValue("");
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }

    @Override
    public void propertyChange(ObserverEvent<String, String> event) {
        Platform.runLater(() -> {
            System.out.println(event);
            if (event.getPropertyName().contains("rented")) {
                Car car = (new Gson()).fromJson(event.getValue2(), Car.class);
                errorLabel.setValue(event.getValue1() + " rented " + car);
            } else if (event.getPropertyName().contains("return")) {
                errorLabel.setValue(event.getValue1() + " just returned a car");
            }
        });
    }
}
