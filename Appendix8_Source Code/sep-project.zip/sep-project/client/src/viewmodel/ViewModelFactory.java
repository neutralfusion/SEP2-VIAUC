package viewmodel;

import model.Model;

public class ViewModelFactory {
    private final ViewState viewState;
    private final LoginViewModel loginViewModel;
    private final ManageCarsViewModel manageCarsViewModel;
    private final RegisterViewModel registerViewModel;
    private final RentCarViewModel rentCarViewModel;
    private final RoleSelectionViewModel roleSelectionViewModel;
    private final EditDetailsViewModel editDetailsViewModel;
    private final UserDashboardViewModel userDashboardViewModel;
    private final EmployeeDashboardViewModel employeeDashboardViewModel;
    private final CarListViewModel carListViewModel;
    private final UserListViewModel userListViewModel;

    public ViewModelFactory(Model model) {
        viewState = new ViewState();
        loginViewModel = new LoginViewModel(model, viewState);
        manageCarsViewModel = new ManageCarsViewModel(model, viewState);
        registerViewModel = new RegisterViewModel(model, viewState);
        rentCarViewModel = new RentCarViewModel(model, viewState);
        roleSelectionViewModel = new RoleSelectionViewModel(model, viewState);
        editDetailsViewModel = new EditDetailsViewModel(model, viewState);
        userDashboardViewModel = new UserDashboardViewModel(model, viewState);
        employeeDashboardViewModel = new EmployeeDashboardViewModel(model, viewState);
        carListViewModel = new CarListViewModel(model, viewState);
        userListViewModel = new UserListViewModel(model, viewState);
    }

    public LoginViewModel getLoginViewModel() {
        return loginViewModel;
    }

    public CarListViewModel getCarListViewModel() {
        return carListViewModel;
    }

    public UserListViewModel getUserListViewModel() {
        return userListViewModel;
    }

    public ManageCarsViewModel getManageCarsViewModel() {
        return manageCarsViewModel;
    }

    public RegisterViewModel getRegisterViewModel() {
        return registerViewModel;
    }

    public RentCarViewModel getRentCarViewModel() {
        return rentCarViewModel;
    }

    public RoleSelectionViewModel getRoleSelectionViewModel() {
        return roleSelectionViewModel;
    }

    public EditDetailsViewModel getEditDetailsViewModel() {
        return editDetailsViewModel;
    }

    public UserDashboardViewModel getUserDashboardViewModel() {
        return userDashboardViewModel;
    }

    public EmployeeDashboardViewModel getEmployeeDashboardViewModel() {
        return employeeDashboardViewModel;
    }

    public ViewState getViewState() {
        return viewState;
    }
}
