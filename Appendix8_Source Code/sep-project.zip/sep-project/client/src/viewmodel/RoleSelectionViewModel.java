package viewmodel;

import model.Model;

public class RoleSelectionViewModel {
    private final Model model;
    private final ViewState state;

    public RoleSelectionViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
    }

}
