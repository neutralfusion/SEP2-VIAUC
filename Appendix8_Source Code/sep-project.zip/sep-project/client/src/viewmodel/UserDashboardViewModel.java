package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Car;
import model.Model;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class UserDashboardViewModel {
    private final Model model;
    private final ViewState state;
    private final ObservableList<CarViewModel> clientCars;

    private StringProperty errorLabel;

    public UserDashboardViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        errorLabel = new SimpleStringProperty();
        clientCars = FXCollections.observableArrayList();
        reset();
    }

    public void reset() {
        errorLabel.setValue("");
        loadCarList();
    }

    private void loadCarList() {
        clientCars.clear();
        try {
            ArrayList<Car> carsFromModel = model.getRentedCars(state.getUsername());
            for (Car c : carsFromModel) {
                clientCars.add(new CarViewModel(c));
            }
        } catch (RemoteException re) {
            re.printStackTrace();
        }
    }

    public void returnCar(CarViewModel car) {
        try {
            clientCars.remove(car);
            model.returnCar(state.getUsername(), car.getLicensePlateProperty());
        } catch (RemoteException re) {
            re.printStackTrace();
        }
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }

    public ObservableList<CarViewModel> getClientCars() {
        return clientCars;
    }
}
