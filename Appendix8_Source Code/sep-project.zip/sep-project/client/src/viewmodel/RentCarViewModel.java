package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Car;
import model.Model;
import model.Place;
import model.Type;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class RentCarViewModel {
    private final Model model;
    private final ViewState state;
    private final ObservableList<String> carTypes, cars, places;
    private final StringProperty errorLabel, selectedType, selectedCar, selectedPick, selectedReturn;

    public RentCarViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        errorLabel = new SimpleStringProperty();
        selectedCar = new SimpleStringProperty();
        selectedType = new SimpleStringProperty();
        selectedReturn = new SimpleStringProperty();
        selectedPick = new SimpleStringProperty();
        carTypes = FXCollections.observableArrayList();
        cars = FXCollections.observableArrayList();
        places = FXCollections.observableArrayList();
        reset();
    }

    public void reset() {
        errorLabel.setValue("");
        carTypes.clear();
        cars.clear();
        places.clear();
        carTypes.addAll(setCarTypes());
        cars.addAll(setCars());
        places.setAll(setPlaces());
    }

    public boolean rent() {
        try {
            if (selectedCar.get() != null && selectedCar.get() != null && selectedPick.get() != null && selectedReturn.get() != null) {
                String[] carArr = selectedCar.get().split(", ");
                String licensePlate = carArr[carArr.length - 1];
                String[] pickingArr = selectedPick.get().split(": ");
                String[] returningArr = selectedReturn.get().split(": ");
                if (model.rentCar(state.getUsername(), licensePlate, pickingArr[pickingArr.length - 1], returningArr[returningArr.length - 1]) != null)
                    return true;
            } else errorLabel.setValue("Please select a value for all fields");
        } catch (RemoteException re) {
            //
        }

        return false;
    }

    private ArrayList<String> setCars() {
        try {
            ArrayList<Car> carsFromModel = model.getAllCars();
            ArrayList<String> cars = new ArrayList<>();
            for (Car c: carsFromModel) {
                if (c.getType().getCarType().equals(selectedType.get()) && !c.isRented()) {
                    cars.add(c.toString());
                }
            }
            return cars;
        } catch (RemoteException re) {
            re.printStackTrace();
        }

        return new ArrayList<>();
    }

    private ArrayList<String> setPlaces() {
       try {
           ArrayList<Place> placesFromModel = model.getAllPlaces();
           ArrayList<String> places = new ArrayList<>();
           for (Place p : placesFromModel) {
               places.add(p.toString());
           }
           return places;
       } catch (RemoteException re) {
           re.printStackTrace();
       }

       return new ArrayList<>();
    }

    private ArrayList<String> setCarTypes() {
        try {
            ArrayList<Type> typesFromModel = model.getCarTypes();
            ArrayList<String> types = new ArrayList<>();
            for (Type t : typesFromModel) {
                types.add(t.getCarType());
            }
            return types;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return new ArrayList<>();
    }

    public void selectType(String type) {
        selectedType.setValue(type);
        cars.setAll(setCars());
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }

    public void selectCar(String car) {
        selectedCar.setValue(car);
    }

    public void selectPicking(String picking) {
        selectedPick.setValue(picking);
    }

    public void selectReturning(String returning) {
        selectedReturn.setValue(returning);
    }

    public ObservableList<String> getPlaces() {
        return places;
    }

    public ObservableList<String> getCars() {
        return cars;
    }

    public ObservableList<String> getCarTypes() {
        return carTypes;
    }
}
