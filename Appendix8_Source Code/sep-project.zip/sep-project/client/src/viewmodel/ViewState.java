package viewmodel;

public class ViewState {
    public final static String CLIENT = "client";
    private String username, userType;
    private int carId;

    public ViewState() {
        username = null;
        userType = null;
        carId = Integer.MIN_VALUE;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }
}
