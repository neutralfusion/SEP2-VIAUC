package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Model;
import model.User;

import java.rmi.RemoteException;

public class EditDetailsViewModel {
    private final Model model;
    private final ViewState state;
    private final StringProperty name, surname, phoneNo, password, errorLabel;
    private User userDetails;

    public EditDetailsViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        name = new SimpleStringProperty();
        surname = new SimpleStringProperty();
        phoneNo = new SimpleStringProperty();
        password = new SimpleStringProperty();
        errorLabel = new SimpleStringProperty();
    }

    public void reset() {
        try {
            System.out.println(state.getUsername());
            userDetails = model.getUserDetails(state.getUsername());
            System.out.println(userDetails.getPassword());
            System.out.println(userDetails.getPhoneNo());
            name.setValue(userDetails.getName());
            surname.setValue(userDetails.getSurname());
            phoneNo.setValue(userDetails.getPhoneNo());
            password.setValue(userDetails.getPassword());
            errorLabel.setValue("");
        } catch (RemoteException re) {
            //
        }
    }

    public void edit() {
        if (!userDetails.getName().equals(name.get()) || !userDetails.getSurname().equals(surname.get())
                || !userDetails.getPhoneNo().equals(phoneNo.get()) || !userDetails.getPassword().equals(password.get())) {
            try {
                User user = new User(name.get(), surname.get(), phoneNo.get(), state.getUsername(), password.get());
                model.updateDetails(user.getName(), user.getSurname(), user.getPhoneNo(), user.getUsername(), user.getPassword());
            } catch (IllegalArgumentException e) {
                errorLabel.set(e.getMessage());
                throw new IllegalArgumentException("Error");
            } catch (RemoteException re) {
                //
            }
        }
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }

    public StringProperty getName() {
        return name;
    }

    public StringProperty getSurname() {
        return surname;
    }

    public StringProperty getPhoneNo() {
        return phoneNo;
    }

    public StringProperty getPassword() {
        return password;
    }
}
