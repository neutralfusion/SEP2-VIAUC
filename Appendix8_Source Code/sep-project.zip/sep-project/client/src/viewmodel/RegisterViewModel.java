package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Model;
import model.User;

import java.rmi.RemoteException;

public class RegisterViewModel {
    private final Model model;
    private final ViewState state;
    private final StringProperty name, surname, phoneNo, username, password, errorLabel;

    public RegisterViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        this.name = new SimpleStringProperty();
        this.surname = new SimpleStringProperty();
        this.phoneNo = new SimpleStringProperty();
        this.username = new SimpleStringProperty();
        this.password = new SimpleStringProperty();
        this.errorLabel = new SimpleStringProperty();
    }

    public void reset() {
        name.set("");
        surname.set("");
        phoneNo.set("");
        username.set("");
        password.set("");
        errorLabel.set("");
    }

    public boolean register() {
        try {
            User user = new User(name.get(), surname.get(), phoneNo.get(), username.get(), password.get());
            model.register(user.getName(), user.getSurname(), user.getPhoneNo(), user.getUsername(), user.getPassword());
            state.setUsername(user.getUsername());
            state.setUserType(ViewState.CLIENT);
        } catch (RemoteException re) {
            //
        } catch (IllegalArgumentException e) {
            errorLabel.set(e.getMessage());
            return false;
        }
        return true;
    }

    public StringProperty getName() {
        return name;
    }

    public StringProperty getSurname() {
        return surname;
    }

    public StringProperty getPhoneNo() {
        return phoneNo;
    }

    public StringProperty getUsername() {
        return username;
    }

    public StringProperty getPassword() {
        return password;
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }
}
