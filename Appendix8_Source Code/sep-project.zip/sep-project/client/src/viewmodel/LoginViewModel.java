package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Model;

import java.rmi.RemoteException;

public class LoginViewModel {
    private final Model model;
    private final ViewState state;
    private final StringProperty username, password, errorMessage;

    public LoginViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        this.username = new SimpleStringProperty();
        this.password = new SimpleStringProperty();
        this.errorMessage = new SimpleStringProperty();
    }

    public void reset() {
        username.setValue("");
        password.setValue("");
        errorMessage.setValue("");
    }

    public StringProperty getUsername() {
        return username;
    }

    public StringProperty getPassword() {
        return password;
    }

    public StringProperty getErrorMessage() {
        return errorMessage;
    }

    public String login() {
        try {
            boolean login = model.login(username.get(), password.get(), state.getUserType());
            if (login) {
                state.setUsername(username.get());
                return state.getUserType();
            }
            errorMessage.setValue("Invalid credentials");
        } catch (RemoteException re) {
            //
        }
        return null;
    }
}
