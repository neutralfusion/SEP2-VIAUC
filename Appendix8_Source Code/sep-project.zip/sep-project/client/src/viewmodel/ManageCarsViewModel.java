package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Car;
import model.Model;
import model.Type;

import java.rmi.RemoteException;
import java.util.ArrayList;

public class ManageCarsViewModel {
    private final Model model;
    private final ViewState state;
    private final ObservableList<String> carTypes;
    private final StringProperty licensePlate, brand, carModel, errorLabel, selectedType;

    public ManageCarsViewModel(Model model, ViewState state) {
        this.model = model;
        this.state = state;
        licensePlate = new SimpleStringProperty();
        brand = new SimpleStringProperty();
        carModel = new SimpleStringProperty();
        errorLabel = new SimpleStringProperty();
        selectedType = new SimpleStringProperty();
        carTypes = FXCollections.observableArrayList();
        carTypes.addAll(setCarTypes());
    }

    public void reset() {
        carModel.setValue("");
        brand.setValue("");
        licensePlate.setValue("");
        errorLabel.setValue("");
    }

    public boolean addCar() {
        try {
            Car car = new Car(brand.get(), carModel.get(), licensePlate.get(), new Type(selectedType.get()));
            model.addCar(car);
            return true;
        } catch (IllegalArgumentException e) {
            errorLabel.setValue(e.getMessage());
        } catch (RemoteException re) {
            //
        }
        return false;
    }

    public ObservableList<String> getCarTypes() {
        return carTypes;
    }

    public void selectType(String type) {
        selectedType.setValue(type);
    }

    private ArrayList<String> setCarTypes() {
        try {
            ArrayList<Type> typesFromModel = model.getCarTypes();
            ArrayList<String> types = new ArrayList<>();
            for (Type t : typesFromModel) {
                types.add(t.getCarType());
            }
            return types;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return null;
    }

    public StringProperty getBrand() {
        return brand;
    }

    public StringProperty getCarModel() {
        return carModel;
    }

    public StringProperty getLicensePlate() {
        return licensePlate;
    }

    public StringProperty getErrorLabel() {
        return errorLabel;
    }
}
