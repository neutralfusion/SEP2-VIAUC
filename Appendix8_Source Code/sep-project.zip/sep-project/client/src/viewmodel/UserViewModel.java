package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.User;

public class UserViewModel {
    private StringProperty nameProperty, surnameProperty, phoneNumberProperty, usernameProperty;

    public UserViewModel(User user) {
        nameProperty = new SimpleStringProperty(user.getName());
        surnameProperty = new SimpleStringProperty(user.getSurname());
        phoneNumberProperty = new SimpleStringProperty(user.getPhoneNo());
        usernameProperty = new SimpleStringProperty(user.getUsername());
    }


    public String getNameProperty() {
        return nameProperty.get();
    }

    public StringProperty namePropertyProperty() {
        return nameProperty;
    }

    public String getSurnameProperty() {
        return surnameProperty.get();
    }

    public StringProperty surnamePropertyProperty() {
        return surnameProperty;
    }

    public String getPhoneNumberProperty() {
        return phoneNumberProperty.get();
    }

    public StringProperty phoneNumberPropertyProperty() {
        return phoneNumberProperty;
    }

    public String getUsernameProperty() {
        return usernameProperty.get();
    }

    public StringProperty usernamePropertyProperty() {
        return usernameProperty;
    }
}
