package viewmodel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Car;

public class CarViewModel {

    private StringProperty brandStringProperty, typeStringProperty, modelStringProperty, licensePlateProperty;

    public CarViewModel(Car car) {
        brandStringProperty = new SimpleStringProperty(car.getBrand());
        typeStringProperty = new SimpleStringProperty(car.getType().getCarType());
        modelStringProperty = new SimpleStringProperty(car.getModel());
        licensePlateProperty = new SimpleStringProperty(car.getLicensePlate());
    }


    public String getBrandStringProperty() {
        return brandStringProperty.get();
    }

    public StringProperty brandStringPropertyProperty() {
        return brandStringProperty;
    }

    public String getTypeStringProperty() {
        return typeStringProperty.get();
    }

    public StringProperty typeStringPropertyProperty() {
        return typeStringProperty;
    }

    public String getModelStringProperty() {
        return modelStringProperty.get();
    }

    public StringProperty modelStringPropertyProperty() {
        return modelStringProperty;
    }

    public String getLicensePlateProperty() {
        return licensePlateProperty.get();
    }

    public StringProperty licensePlatePropertyProperty() {
        return licensePlateProperty;
    }
}
