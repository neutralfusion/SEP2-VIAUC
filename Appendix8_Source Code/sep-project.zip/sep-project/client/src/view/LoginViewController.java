package view;

import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class LoginViewController extends ViewController {

    @FXML private Hyperlink registerLink;
    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private Text errorLabel;

    @Override
    protected void init() throws InterruptedException {
        usernameField.textProperty().bindBidirectional(super.getViewModelFactory().getLoginViewModel().getUsername());
        passwordField.textProperty().bindBidirectional(super.getViewModelFactory().getLoginViewModel().getPassword());
        errorLabel.textProperty().bind(super.getViewModelFactory().getLoginViewModel().getErrorMessage());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getLoginViewModel().reset();
        registerLink.setVisible(!super.getViewModelFactory().getViewState().getUserType().equals("employee"));
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("RoleSelectionView.fxml");
    }

    @FXML
    private void onLogin() {
        String userType = super.getViewModelFactory().getLoginViewModel().login();
        if (userType != null) {
            switch (userType.toLowerCase()) {
                case "client" -> super.getViewHandler().openView("UserDashboardView.fxml");
                case "employee" -> super.getViewHandler().openView("EmployeeDashboardView.fxml");
            }
        }
    }

    @FXML
    private void onRegister() {
        super.getViewHandler().openView("RegisterView.fxml");
    }
}
