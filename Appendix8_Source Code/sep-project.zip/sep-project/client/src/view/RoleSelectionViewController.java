package view;

import javafx.fxml.FXML;

public class RoleSelectionViewController extends ViewController {

    @Override
    protected void init() throws InterruptedException {

    }

    @Override
    public void reset() throws InterruptedException {
        //
    }

    @FXML
    private void onCustomer() {
        super.getViewModelFactory().getViewState().setUserType("client");
        super.getViewHandler().openView("LoginView.fxml");
    }

    @FXML
    private void onEmployee() {
        super.getViewModelFactory().getViewState().setUserType("employee");
        super.getViewHandler().openView("LoginView.fxml");
    }
}
