package view;

import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class ManageCarsViewController extends ViewController {

    @FXML private ChoiceBox<String> carTypeChoiceBox;
    @FXML private TextField brandTextField;
    @FXML private TextField modelTextField;
    @FXML private TextField licensePlateTextField;
    @FXML private Text errorLabel;

    @Override
    protected void init() throws InterruptedException {
        brandTextField.textProperty().bindBidirectional(super.getViewModelFactory().getManageCarsViewModel().getBrand());
        modelTextField.textProperty().bindBidirectional(super.getViewModelFactory().getManageCarsViewModel().getCarModel());
        licensePlateTextField.textProperty().bindBidirectional(super.getViewModelFactory().getManageCarsViewModel().getLicensePlate());
        errorLabel.textProperty().bind(super.getViewModelFactory().getManageCarsViewModel().getErrorLabel());
        carTypeChoiceBox.setItems(super.getViewModelFactory().getManageCarsViewModel().getCarTypes());
        carTypeChoiceBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obs, String ov, String nv) -> super.getViewModelFactory().getManageCarsViewModel().selectType(nv));
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getManageCarsViewModel().reset();
        carTypeChoiceBox.getSelectionModel().clearSelection();
    }

    @FXML
    private void onAdd() {
        if (super.getViewModelFactory().getManageCarsViewModel().addCar()) {
            onBack();
        }
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("EmployeeDashboardView.fxml");
    }
}
