package view;

import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import viewmodel.ViewModelFactory;

public class ViewHandler extends ViewCreator {

    private final Scene scene;
    private Stage stage;
    private final ViewModelFactory viewModelFactory;
    private String title;

    public ViewHandler(ViewModelFactory viewModelFactory) {
        this.viewModelFactory = viewModelFactory;
        scene = new Scene(new Region());
    }

    public void start(Stage stage) {
        this.stage = stage;
        openView("RoleSelectionView.fxml");
    }

    public void openView(String id) {
        title = id;
        Region root = super.getViewController(id).getRoot();
        scene.setRoot(root);
        stage.setTitle(title);
        stage.setScene(scene);
        stage.setWidth(root.getPrefWidth());
        stage.setHeight(root.getPrefHeight());
        stage.show();
    }

    public String getTitle() {
        return title;
    }

    @Override
    public void initViewController(ViewController controller, Region root) {
        try {
            controller.init(this, viewModelFactory, root);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
