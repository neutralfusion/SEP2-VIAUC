package view;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import viewmodel.CarViewModel;

public class UserDashboardViewController extends ViewController {

    @FXML private TableView<CarViewModel> carsTable;
    @FXML private TableColumn<CarViewModel, String> brandColumn, modelColumn, typeColumn, licensePlateColumn;
    @FXML private Label errorLabel;

    @Override
    protected void init() throws InterruptedException {
        errorLabel.textProperty().bind(super.getViewModelFactory().getUserDashboardViewModel().getErrorLabel());
        brandColumn.setCellValueFactory(c -> c.getValue().brandStringPropertyProperty());
        modelColumn.setCellValueFactory(c -> c.getValue().modelStringPropertyProperty());
        typeColumn.setCellValueFactory(c -> c.getValue().typeStringPropertyProperty());
        licensePlateColumn.setCellValueFactory(c -> c.getValue().licensePlatePropertyProperty());
        carsTable.setItems(super.getViewModelFactory().getUserDashboardViewModel().getClientCars());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getUserDashboardViewModel().reset();
    }

    @FXML
    private void onRent() {
        super.getViewHandler().openView("RentCarView.fxml");
    }

    @FXML
    private void onEdit() {
        super.getViewHandler().openView("EditDetailsView.fxml");
    }

    @FXML
    private void onReturn() {
        if (carsTable.getSelectionModel().getSelectedItem() != null) {
            super.getViewModelFactory().getUserDashboardViewModel().returnCar(carsTable.getSelectionModel().getSelectedItem());
        }
    }
}
