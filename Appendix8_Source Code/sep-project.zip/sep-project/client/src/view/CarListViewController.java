package view;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import viewmodel.CarViewModel;

public class CarListViewController extends ViewController {

    @FXML private TableView<CarViewModel> carListTable;
    @FXML private TableColumn<CarViewModel, String> brandColumn, modelColumn, typeColumn, licensePlateColumn;

    @Override
    protected void init() throws InterruptedException {
        brandColumn.setCellValueFactory(c -> c.getValue().brandStringPropertyProperty());
        modelColumn.setCellValueFactory(c -> c.getValue().modelStringPropertyProperty());
        typeColumn.setCellValueFactory(c -> c.getValue().typeStringPropertyProperty());
        licensePlateColumn.setCellValueFactory(c -> c.getValue().licensePlatePropertyProperty());
        carListTable.setItems(super.getViewModelFactory().getCarListViewModel().getCarList());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getCarListViewModel().reset();
    }

    @FXML
    private void onDelete() {
        super.getViewModelFactory().getCarListViewModel().removeCar(carListTable.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("EmployeeDashboardView.fxml");
    }
}
