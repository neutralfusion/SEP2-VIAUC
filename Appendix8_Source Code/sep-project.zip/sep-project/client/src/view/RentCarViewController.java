package view;

import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.text.Text;

public class RentCarViewController extends ViewController {

    @FXML private ChoiceBox<String> carTypeChoiceBox, carChoiceBox, pickPlaceChoiceBox, returnPlaceChoiceBox;
    @FXML private Text errorLabel;

    @Override
    protected void init() throws InterruptedException {
        errorLabel.textProperty().bind(super.getViewModelFactory().getRentCarViewModel().getErrorLabel());
        carTypeChoiceBox.setItems(super.getViewModelFactory().getRentCarViewModel().getCarTypes());
        carChoiceBox.setItems(super.getViewModelFactory().getRentCarViewModel().getCars());
        pickPlaceChoiceBox.setItems(super.getViewModelFactory().getRentCarViewModel().getPlaces());
        returnPlaceChoiceBox.setItems(super.getViewModelFactory().getRentCarViewModel().getPlaces());
        carTypeChoiceBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obs, String ov, String nv) -> super.getViewModelFactory().getRentCarViewModel().selectType(nv));
        carChoiceBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obs, String ov, String nv) -> super.getViewModelFactory().getRentCarViewModel().selectCar(nv));
        pickPlaceChoiceBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obs, String ov, String nv) -> super.getViewModelFactory().getRentCarViewModel().selectPicking(nv));
        returnPlaceChoiceBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> obs, String ov, String nv) -> super.getViewModelFactory().getRentCarViewModel().selectReturning(nv));
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getRentCarViewModel().reset();
    }

    @FXML
    private void onRent() {
        if (super.getViewModelFactory().getRentCarViewModel().rent()) {
            super.getViewHandler().openView("UserDashboardView.fxml");
        };
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("UserDashboardView.fxml");
    }
}
