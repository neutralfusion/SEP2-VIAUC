package view;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import viewmodel.UserViewModel;

public class UserListViewController extends ViewController {

    @FXML private TableView<UserViewModel> userListTable;
    @FXML private TableColumn<UserViewModel, String> nameColumn, surnameColumn, phoneNumberColumn, usernameColumn;

    @Override
    protected void init() throws InterruptedException {
        nameColumn.setCellValueFactory(c -> c.getValue().namePropertyProperty());
        surnameColumn.setCellValueFactory(c -> c.getValue().surnamePropertyProperty());
        phoneNumberColumn.setCellValueFactory(c -> c.getValue().phoneNumberPropertyProperty());
        usernameColumn.setCellValueFactory(c -> c.getValue().usernamePropertyProperty());
        userListTable.setItems(super.getViewModelFactory().getUserListViewModel().getUserList());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getUserListViewModel().reset();
    }

    @FXML private void onBack() {
        super.getViewHandler().openView("EmployeeDashboardView.fxml");
    }
}
