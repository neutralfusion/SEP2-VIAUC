package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class EditDetailsViewController extends ViewController {

    @FXML
    private TextField nameTextField, surnameTextField, phoneNoTextField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label errorLabel;
    @FXML
    private Button editButton;
    private boolean isDisabled;

    @Override
    protected void init() throws InterruptedException {
        this.isDisabled = true;
        nameTextField.textProperty().bindBidirectional(super.getViewModelFactory().getEditDetailsViewModel().getName());
        surnameTextField.textProperty().bindBidirectional(super.getViewModelFactory().getEditDetailsViewModel().getSurname());
        phoneNoTextField.textProperty().bindBidirectional(super.getViewModelFactory().getEditDetailsViewModel().getPhoneNo());
        passwordField.textProperty().bindBidirectional(super.getViewModelFactory().getEditDetailsViewModel().getPassword());
        errorLabel.textProperty().bind(super.getViewModelFactory().getEditDetailsViewModel().getErrorLabel());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getEditDetailsViewModel().reset();
        this.isDisabled = true;
        editButton.setText("Edit");
        disableFields(true);
    }

    private void disableFields(boolean isDisabled) {
        nameTextField.setDisable(isDisabled);
        surnameTextField.setDisable(isDisabled);
        phoneNoTextField.setDisable(isDisabled);
        passwordField.setDisable(isDisabled);
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("UserDashboardView.fxml");
    }

    @FXML
    private void onEdit() {
        try {
            super.getViewModelFactory().getEditDetailsViewModel().edit();
            isDisabled = !isDisabled;
            disableFields(isDisabled);
            editButton.setText((isDisabled) ? "Edit" : "Save");
        } catch (IllegalArgumentException e) {
            // if error, don't toggle fields
        }
    }
}
