package view;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class RegisterViewController extends ViewController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField surnameField;

    @FXML
    private TextField phoneNoField;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField passwordField;

    @FXML private Text errorLabel;

    @Override
    protected void init() throws InterruptedException {
        nameField.textProperty().bindBidirectional(super.getViewModelFactory().getRegisterViewModel().getName());
        surnameField.textProperty().bindBidirectional(super.getViewModelFactory().getRegisterViewModel().getSurname());
        phoneNoField.textProperty().bindBidirectional(super.getViewModelFactory().getRegisterViewModel().getPhoneNo());
        usernameField.textProperty().bindBidirectional(super.getViewModelFactory().getRegisterViewModel().getUsername());
        passwordField.textProperty().bindBidirectional(super.getViewModelFactory().getRegisterViewModel().getPassword());
        errorLabel.textProperty().bind(super.getViewModelFactory().getRegisterViewModel().getErrorLabel());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getRegisterViewModel().reset();
    }

    @FXML
    private void onBack() {
        super.getViewHandler().openView("LoginView.fxml");
    }

    @FXML
    private void onRegister() {
        if (super.getViewModelFactory().getRegisterViewModel().register()) {
            super.getViewHandler().openView("UserDashboardView.fxml");
        }
    }
}
