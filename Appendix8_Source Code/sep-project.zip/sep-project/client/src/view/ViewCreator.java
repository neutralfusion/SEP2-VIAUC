package view;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Region;

import java.io.IOException;
import java.util.HashMap;

public abstract class ViewCreator {

    private final HashMap<String, ViewController> map;

    public ViewCreator() {
        this.map = new HashMap<>();
    }

    public ViewController getViewController(String id) {
        // load fxml and add to hashmap
        ViewController viewController = map.computeIfAbsent(id, this::loadFromFXML);
        try {
            viewController.reset();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return viewController;
    }



    public abstract void initViewController(ViewController controller, Region root);

    private ViewController loadFromFXML(String fxmlFile) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(fxmlFile));
        try {
            Region root = loader.load();
            ViewController viewController = loader.getController();
            initViewController(viewController, root);
            return viewController;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
