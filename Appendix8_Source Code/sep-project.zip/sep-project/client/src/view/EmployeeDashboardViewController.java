package view;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class EmployeeDashboardViewController extends ViewController {

    @FXML private Text errorLabel;

    @Override
    protected void init() throws InterruptedException {
        errorLabel.textProperty().bind(super.getViewModelFactory().getEmployeeDashboardViewModel().getErrorLabel());
    }

    @Override
    public void reset() throws InterruptedException {
        super.getViewModelFactory().getEmployeeDashboardViewModel().reset();
    }

    @FXML
    private void onManage() {
        super.getViewHandler().openView("ManageCarsView.fxml");
    }

    @FXML
    private void onDelete() {
        super.getViewHandler().openView("CarListView.fxml");
    }

    @FXML
    private void onClientList() {
        super.getViewHandler().openView("UserListView.fxml");
    }
}
