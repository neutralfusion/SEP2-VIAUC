package mediator;

import model.*;
import utility.observer.event.ObserverEvent;
import utility.observer.listener.GeneralListener;
import utility.observer.listener.RemoteListener;
import utility.observer.subject.PropertyChangeHandler;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class ClientModelManager implements ClientModel, RemoteListener<String, String> {
    private Model model;
    private final RemoteModel server;
    private final PropertyChangeHandler<String, String> property;

    public ClientModelManager(Model model) throws MalformedURLException, NotBoundException, RemoteException {
        this.model = model;
        server = (RemoteModel) Naming.lookup("rmi://localhost:1099/wheelsquick");
        UnicastRemoteObject.exportObject(this, 0);
        server.addListener(this);
        property = new PropertyChangeHandler<>(this, true);
    }

    @Override
    public void register(String fname, String lname, String phoneNo, String username, String password) throws RemoteException {
        server.register(fname, lname, phoneNo, username, password);
    }

    @Override
    public boolean login(String username, String password, String userType) throws RemoteException {
        return server.login(username, password, userType);
    }

    @Override
    public void updateDetails(String fname, String lname, String phoneNo, String username, String password) throws RemoteException {
        server.updateDetails(fname, lname, phoneNo, username, password);
    }

    @Override
    public User getUserDetails(String username) throws RemoteException {
        return server.getUserDetails(username);
    }

    @Override
    public ArrayList<User> getAllClients() throws RemoteException {
        return server.getAllClients();
    }

    @Override
    public ArrayList<Type> getCarTypes() throws RemoteException {
        return server.getCarTypes();
    }

    @Override
    public ArrayList<Car> getAllCars() throws RemoteException {
        return server.getAllCars();
    }

    @Override
    public void addCar(Car car) throws RemoteException {
        server.addCar(car);
    }

    @Override
    public void removeCar(String licensePlate) throws RemoteException {
        server.removeCar(licensePlate);
    }

    @Override
    public ArrayList<Place> getAllPlaces() throws RemoteException {
        return server.getAllPlaces();
    }

    @Override
    public Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) throws RemoteException {
        return server.rentCar(username, licensePlate, pickingPlace, returningPlace);
    }

    @Override
    public void returnCar(String username, String licensePlate) throws RemoteException {
        server.returnCar(username, licensePlate);
    }

    @Override
    public ArrayList<Car> getRentedCars(String username) throws RemoteException {
        return server.getRentedCars(username);
    }

    @Override
    public void propertyChange(ObserverEvent<String, String> event) {
        property.firePropertyChange(event);
        System.out.println("event in ClientModelManager");
    }

    @Override
    public boolean addListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.addListener(listener, propertyNames);
    }

    @Override
    public boolean removeListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.removeListener(listener, propertyNames);
    }
}
