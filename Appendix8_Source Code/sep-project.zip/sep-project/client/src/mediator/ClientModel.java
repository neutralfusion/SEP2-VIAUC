package mediator;

import model.Car;
import model.Place;
import model.Type;
import model.User;
import utility.observer.subject.LocalSubject;

import java.rmi.RemoteException;
import java.util.ArrayList;

public interface ClientModel extends LocalSubject<String, String> {
    void register(String fname, String lname, String phoneNo, String username, String password) throws RemoteException;
    boolean login(String username, String password, String userType) throws RemoteException;
    void updateDetails(String fname, String lname, String phoneNo, String username, String password) throws RemoteException;
    User getUserDetails(String username) throws RemoteException;
    ArrayList<User> getAllClients() throws RemoteException;
    ArrayList<Type> getCarTypes() throws RemoteException;
    ArrayList<Car> getAllCars() throws RemoteException;
    void addCar(Car car) throws RemoteException;
    void removeCar(String licensePlate) throws RemoteException;
    ArrayList<Place> getAllPlaces() throws RemoteException;
    Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) throws RemoteException;
    void returnCar(String username, String licensePlate) throws RemoteException;
    ArrayList<Car> getRentedCars(String username) throws RemoteException;
}
