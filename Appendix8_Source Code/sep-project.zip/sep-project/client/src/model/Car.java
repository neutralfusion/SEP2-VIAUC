package model;

import java.io.Serializable;

public class Car implements Serializable {
    private String brand, model, licensePlate;
    private Type type;
    private boolean isRented;

    public Car(String brand, String model, String licensePlate, Type type) {
        checkValues(brand, model, licensePlate, type);
        this.brand = brand;
        this.model = model;
        this.licensePlate = licensePlate;
        this.type = type;
    }

    private void checkValues(String brand, String model, String licensePlate, Type type) {
        if (brand == null || brand.equals("")) {
            throw new IllegalArgumentException("Please enter the car brand");
        }
        if (model == null || model.equals("")) {
            throw new IllegalArgumentException("Please enter the car model");
        }
        if (licensePlate == null || licensePlate.equals("") || licensePlate.length() != 7) {
            throw new IllegalArgumentException("Invalid license plate");
        }
        if (type == null) {
            throw new IllegalArgumentException("Please select a car type");
        } else if (type.getCarType().equals("")) {
            throw new IllegalArgumentException("Invalid car type");
        }
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public boolean isRented() {
        return isRented;
    }

    public void setRented(boolean rented) {
        isRented = rented;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return brand + " " + model + ", " + licensePlate;
    }
}
