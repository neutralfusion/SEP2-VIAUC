package model;


import mediator.ClientModel;
import mediator.ClientModelManager;
import utility.observer.event.ObserverEvent;
import utility.observer.listener.GeneralListener;
import utility.observer.listener.LocalListener;
import utility.observer.subject.PropertyChangeHandler;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class ModelManager implements Model, LocalListener<String, String> {

    private final ClientModel clientModelManager;
    private final PropertyChangeHandler<String, String> property;

    public ModelManager() throws MalformedURLException, NotBoundException, RemoteException {
        clientModelManager = new ClientModelManager(this);
        clientModelManager.addListener(this);
        property = new PropertyChangeHandler<>(this, true);
    }

    @Override
    public void register(String fname, String lname, String phoneNo, String username, String password) throws RemoteException {
        clientModelManager.register(fname, lname, phoneNo, username, password);
    }

    @Override
    public boolean login(String username, String password, String userType) throws RemoteException {
        return clientModelManager.login(username, password, userType);
    }

    @Override
    public void updateDetails(String fname, String lname, String phoneNo, String username, String password) throws RemoteException {
        clientModelManager.updateDetails(fname, lname, phoneNo, username, password);
    }

    @Override
    public User getUserDetails(String username) throws RemoteException {
        return clientModelManager.getUserDetails(username);
    }

    @Override
    public ArrayList<User> getAllClients() throws RemoteException {
        return clientModelManager.getAllClients();
    }

    @Override
    public ArrayList<Type> getCarTypes() throws RemoteException {
        return clientModelManager.getCarTypes();
    }

    @Override
    public ArrayList<Car> getAllCars() throws RemoteException {
        return clientModelManager.getAllCars();
    }

    @Override
    public void addCar(Car car) throws RemoteException {
        clientModelManager.addCar(car);
    }

    @Override
    public void removeCar(String licensePlate) throws RemoteException {
        clientModelManager.removeCar(licensePlate);
    }

    @Override
    public ArrayList<Place> getAllPlaces() throws RemoteException {
        return clientModelManager.getAllPlaces();
    }

    @Override
    public Car rentCar(String username, String licensePlate, String pickingPlace, String returningPlace) throws RemoteException {
        return clientModelManager.rentCar(username, licensePlate, pickingPlace, returningPlace);
    }

    @Override
    public void returnCar(String username, String licensePlate) throws RemoteException {
        clientModelManager.returnCar(username, licensePlate);
    }

    @Override
    public ArrayList<Car> getRentedCars(String username) throws RemoteException {
        return clientModelManager.getRentedCars(username);
    }

    @Override
    public void propertyChange(ObserverEvent<String, String> event) {
        System.out.println("Event in ModelManager");
        property.firePropertyChange(event.getPropertyName(), event.getValue1(), event.getValue2());
    }

    @Override
    public boolean addListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.addListener(listener, propertyNames);
    }

    @Override
    public boolean removeListener(GeneralListener<String, String> listener, String... propertyNames) {
        return property.removeListener(listener, propertyNames);
    }
}
