package model;

import java.io.Serializable;

public class User implements Serializable {
    private String name, surname, username, password, phoneNo;
    private boolean isEmployee;

    public User(String name, String surname, String phoneNo, String username, String password) {
        checkDetails(name, surname, phoneNo, username, password);
        this.name = name;
        this.surname = surname;
        this.phoneNo = phoneNo;
        this.username = username;
        this.password = password;
    }

    private void checkDetails(String name, String surname, String phoneNo, String username, String password) {
        if (name == null || name.equals("")) {
            throw new IllegalArgumentException("Please enter name");
        }
        if (surname == null || surname.equals("")) {
            throw new IllegalArgumentException("Please enter surname");
        }
        if (phoneNo == null || phoneNo.equals("")) {
            throw new IllegalArgumentException("Please enter phone number");
        }
        if (phoneNo.length() != 11) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        if (username == null || username.equals("")) {
            throw new IllegalArgumentException("Please enter username");
        }
        if (username.length() < 6 || username.length() > 10) {
            throw new IllegalArgumentException("Username must be between 6 and 10 characters");
        }
        if (password == null || password.equals("")) {
            throw new IllegalArgumentException("Please enter password");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters");
        }
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public boolean isEmployee() {
        return isEmployee;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmployee(boolean employee) {
        isEmployee = employee;
    }
}
