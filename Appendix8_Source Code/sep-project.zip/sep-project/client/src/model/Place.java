package model;

import java.io.Serializable;

public class Place implements Serializable {
    private final String city, address;
    private final int zipCode;

    public Place(String city, String address, int zipCode) {
        this.city = city;
        this.address = address;
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public String getAddress() {
        return address;
    }

    public int getZipCode() {
        return zipCode;
    }

    @Override
    public String toString() {
        return city + ", " + zipCode + ": " + address;
    }
}
