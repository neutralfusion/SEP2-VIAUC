package model;

import java.io.Serializable;

public class Type implements Serializable {
    private String carType;

    public Type(String carType) {
        setCarType(carType);
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        if (carType == null || carType.equals("")) {
            throw new IllegalArgumentException("Please select a car type");
        }
        this.carType = carType;
    }
}
